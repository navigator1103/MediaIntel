// Script to check game plans count
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  try {
    // Count total records in the game plans table
    const totalCount = await prisma.gamePlan.count();
    console.log(`Total records in game plans table: ${totalCount}`);
    
    // Get the most recent records
    const recentRecords = await prisma.gamePlan.findMany({
      take: 5,
      orderBy: {
        id: 'desc'
      },
      include: {
        campaign: true,
        mediaSubType: {
          include: {
            mediaType: true
          }
        },
        country: true
      }
    });
    
    console.log('Most recent records:');
    recentRecords.forEach(record => {
      console.log(`ID: ${record.id}, Campaign: ${record.campaign?.name || 'N/A'}, Start Date: ${record.startDate}, End Date: ${record.endDate}`);
    });
    
  } catch (error) {
    console.error('Error querying the database:', error);
  } finally {
    await prisma.$disconnect();
  }
}

main();
