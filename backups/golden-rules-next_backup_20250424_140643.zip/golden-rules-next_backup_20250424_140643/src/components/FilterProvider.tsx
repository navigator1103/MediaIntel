'use client';

import { ReactNode, useState } from 'react';
import { FilterContext } from './UserNavigation';

interface FilterProviderProps {
  children: ReactNode;
}

export const FilterProvider = ({ children }: FilterProviderProps) => {
  // State for filters - default to Nivea brand (ID 1)
  const [selectedBrand, setSelectedBrand] = useState<string | null>('1');
  const [selectedPlatform, setSelectedPlatform] = useState<string | null>(null);
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);
  
  // Use current month for the filter
  const getCurrentMonth = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    return `${year}-${month}`;
  };
  
  const [selectedMonth, setSelectedMonth] = useState<string>(getCurrentMonth());
  
  // Log the initial filter state
  console.log('Initial filter state:', { selectedBrand: 'Nivea (ID: 1)', selectedMonth: getCurrentMonth() });

  return (
    <FilterContext.Provider 
      value={{
        selectedBrand,
        setSelectedBrand,
        selectedPlatform,
        setSelectedPlatform,
        selectedCountry,
        setSelectedCountry,
        selectedMonth,
        setSelectedMonth
      }}
    >
      {children}
    </FilterContext.Provider>
  );
};

export default FilterProvider;
