import UserDashboard from '@/components/UserDashboard';

export default function UserDashboardPage() {
  return <UserDashboard />;
}
