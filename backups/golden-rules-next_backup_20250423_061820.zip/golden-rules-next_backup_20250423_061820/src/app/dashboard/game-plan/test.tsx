'use client';

import React from 'react';
import DashboardNavigation from '@/components/DashboardNavigation';

export default function GamePlanTest() {
  return (
    <div>
      <DashboardNavigation />
      <h1>Game Plan Test</h1>
    </div>
  );
}
