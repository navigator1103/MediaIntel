'use client';

import React, { useState, useEffect } from 'react';
import Navigation from '@/components/Navigation';
import Link from 'next/link';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  LineChart, Line, ComposedChart, Cell, PieChart, Pie
} from 'recharts';
import { Spinner } from '@/components/ui/spinner';

// Color palette for charts
const COLORS = ['#1F4388', '#2A5CAA', '#3E7DCD', '#5E9FE0', '#7FBCE6', '#A0D8EC', '#C1E4F0', '#E2F0F6'];
const REACH_COLORS = {
  ideal: '#82ca9d',
  current: '#8884d8',
  under: '#f44336',
  over: '#ff9800',
  nice: '#4caf50'
};

export default function SufficiencyDashboard() {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [campaignData, setCampaignData] = useState<any[]>([]);
  const [sidebarExpanded, setSidebarExpanded] = useState(true);
  const [selectedSubRegions, setSelectedSubRegions] = useState<string[]>([]);
  const [selectedCountries, setSelectedCountries] = useState<string[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [subRegionsList, setSubRegionsList] = useState<any[]>([]);
  const [countriesList, setCountriesList] = useState<any[]>([]);
  const [categoriesList, setCategoriesList] = useState<any[]>([]);
  const [combinedReachData, setCombinedReachData] = useState<any[]>([]);
  const [tvReachData, setTvReachData] = useState<any[]>([]);
  const [digitalReachData, setDigitalReachData] = useState<any[]>([]);

  useEffect(() => {
    // Use dummy data instead of fetching from API for now
    loadDummyData();
  }, [selectedSubRegions, selectedCountries, selectedCategories]);

  const loadDummyData = () => {
    setIsLoading(true);
    setError(null);

    // Dummy sub-regions
    const dummySubRegions = [
      { id: '1', name: 'North America' },
      { id: '2', name: 'Europe' },
      { id: '3', name: 'Asia Pacific' },
      { id: '4', name: 'Latin America' },
      { id: '5', name: 'Middle East & Africa' }
    ];

    // Dummy countries
    const dummyCountries = [
      { id: '1', name: 'United States', subRegionId: '1' },
      { id: '2', name: 'United Kingdom', subRegionId: '2' },
      { id: '3', name: 'Germany', subRegionId: '2' },
      { id: '4', name: 'Japan', subRegionId: '3' },
      { id: '5', name: 'China', subRegionId: '3' },
      { id: '6', name: 'Brazil', subRegionId: '4' },
      { id: '7', name: 'Mexico', subRegionId: '4' },
      { id: '8', name: 'UAE', subRegionId: '5' },
      { id: '9', name: 'South Africa', subRegionId: '5' }
    ];

    // Dummy categories
    const dummyCategories = [
      { id: '1', name: 'Deo' },
      { id: '2', name: 'Face Care' },
      { id: '3', name: 'Hand Body' },
      { id: '4', name: 'Lip' },
      { id: '5', name: 'Men' },
      { id: '6', name: 'Sun' }
    ];

    // Dummy campaigns with media items
    const dummyCampaigns = [
      {
        id: '1',
        name: 'Summer Glow',
        targetReach: 5000000,
        currentReach: 4200000,
        mediaItems: [
          {
            id: '1-1',
            mediaSubtype: { mediaType: { name: 'TV' } },
            targetReach: 3000000,
            currentReach: 2500000
          },
          {
            id: '1-2',
            mediaSubtype: { mediaType: { name: 'Digital' } },
            targetReach: 2000000,
            currentReach: 1700000
          }
        ]
      },
      {
        id: '2',
        name: 'Fresh Start',
        targetReach: 3500000,
        currentReach: 3800000,
        mediaItems: [
          {
            id: '2-1',
            mediaSubtype: { mediaType: { name: 'TV' } },
            targetReach: 2000000,
            currentReach: 2200000
          },
          {
            id: '2-2',
            mediaSubtype: { mediaType: { name: 'Digital' } },
            targetReach: 1500000,
            currentReach: 1600000
          }
        ]
      },
      {
        id: '3',
        name: 'Winter Care',
        targetReach: 4000000,
        currentReach: 3600000,
        mediaItems: [
          {
            id: '3-1',
            mediaSubtype: { mediaType: { name: 'TV' } },
            targetReach: 2500000,
            currentReach: 2300000
          },
          {
            id: '3-2',
            mediaSubtype: { mediaType: { name: 'Digital' } },
            targetReach: 1500000,
            currentReach: 1300000
          }
        ]
      },
      {
        id: '4',
        name: 'Everyday Essentials',
        targetReach: 6000000,
        currentReach: 6500000,
        mediaItems: [
          {
            id: '4-1',
            mediaSubtype: { mediaType: { name: 'TV' } },
            targetReach: 3500000,
            currentReach: 3800000
          },
          {
            id: '4-2',
            mediaSubtype: { mediaType: { name: 'Digital' } },
            targetReach: 2500000,
            currentReach: 2700000
          }
        ]
      },
      {
        id: '5',
        name: 'Premium Collection',
        targetReach: 2500000,
        currentReach: 2450000,
        mediaItems: [
          {
            id: '5-1',
            mediaSubtype: { mediaType: { name: 'TV' } },
            targetReach: 1500000,
            currentReach: 1450000
          },
          {
            id: '5-2',
            mediaSubtype: { mediaType: { name: 'Digital' } },
            targetReach: 1000000,
            currentReach: 1000000
          }
        ]
      }
    ];

    // Set filter data
    setSubRegionsList(dummySubRegions);
    setCountriesList(dummyCountries);
    setCategoriesList(dummyCategories);
    setCampaignData(dummyCampaigns);

    // Process data for charts
    processReachData(dummyCampaigns);

    setIsLoading(false);
  };

  const fetchDashboardData = async () => {
    try {
      setIsLoading(true);
      setError(null);

      // Build query params
      const queryParams = new URLSearchParams();
      if (selectedSubRegions.length > 0) {
        queryParams.append('subRegion', selectedSubRegions.join(','));
      }
      if (selectedCountries.length > 0) {
        queryParams.append('country', selectedCountries.join(','));
      }
      if (selectedCategories.length > 0) {
        queryParams.append('category', selectedCategories.join(','));
      }

      const response = await fetch(`/api/media-sufficiency?${queryParams.toString()}`);
      if (!response.ok) {
        throw new Error('Failed to fetch dashboard data');
      }

      const data = await response.json();
      
      // Set filter data
      setSubRegionsList(data.subRegions || []);
      setCountriesList(data.countries || []);
      setCategoriesList(data.categories || []);
      setCampaignData(data.campaigns || []);

      // Process data for charts
      processReachData(data.campaigns || []);

      setIsLoading(false);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      setError('Failed to load dashboard data. Please try again later.');
      setIsLoading(false);
    }
  };

  const processReachData = (campaigns: any[]) => {
    // Process combined reach data
    const combinedData = campaigns.map(campaign => {
      const idealReach = campaign.targetReach || 0;
      const currentReach = campaign.currentReach || 0;
      const reachPercentage = idealReach > 0 ? (currentReach / idealReach) * 100 : 0;
      const status = getReachStatus(reachPercentage);
      
      return {
        name: campaign.name,
        idealReach: 100, // Target is always 100%
        currentReach: reachPercentage, // Current reach as percentage of target
        reachPercentage,
        status,
        // Keep the raw values for the table display
        rawIdealReach: idealReach,
        rawCurrentReach: currentReach
      };
    });
    setCombinedReachData(combinedData);

    // Process TV reach data
    const tvData = campaigns.map(campaign => {
      const tvItems = campaign.mediaItems.filter((item: any) => 
        item.mediaSubtype?.mediaType?.name === 'TV'
      );
      
      const idealReach = tvItems.reduce((sum: number, item: any) => sum + (item.targetReach || 0), 0);
      const currentReach = tvItems.reduce((sum: number, item: any) => sum + (item.currentReach || 0), 0);
      const reachPercentage = idealReach > 0 ? (currentReach / idealReach) * 100 : 0;
      const status = getReachStatus(reachPercentage);
      
      return {
        name: campaign.name,
        idealReach: 100, // Target is always 100%
        currentReach: reachPercentage, // Current reach as percentage of target
        reachPercentage,
        status,
        // Keep the raw values for the table display
        rawIdealReach: idealReach,
        rawCurrentReach: currentReach
      };
    });
    setTvReachData(tvData);

    // Process Digital reach data
    const digitalData = campaigns.map(campaign => {
      const digitalItems = campaign.mediaItems.filter((item: any) => 
        item.mediaSubtype?.mediaType?.name === 'Digital'
      );
      
      const idealReach = digitalItems.reduce((sum: number, item: any) => sum + (item.targetReach || 0), 0);
      const currentReach = digitalItems.reduce((sum: number, item: any) => sum + (item.currentReach || 0), 0);
      const reachPercentage = idealReach > 0 ? (currentReach / idealReach) * 100 : 0;
      const status = getReachStatus(reachPercentage);
      
      return {
        name: campaign.name,
        idealReach: 100, // Target is always 100%
        currentReach: reachPercentage, // Current reach as percentage of target
        reachPercentage,
        status,
        // Keep the raw values for the table display
        rawIdealReach: idealReach,
        rawCurrentReach: currentReach
      };
    });
    setDigitalReachData(digitalData);
  };

  const getReachStatus = (percentage: number): 'under' | 'over' | 'nice' => {
    if (percentage < 90) return 'under';
    if (percentage > 110) return 'over';
    return 'nice';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'under': return REACH_COLORS.under;
      case 'over': return REACH_COLORS.over;
      case 'nice': return REACH_COLORS.nice;
      default: return '#000';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'under': return 'Under';
      case 'over': return 'Over';
      case 'nice': return 'Nice!';
      default: return '';
    }
  };

  const toggleSubRegion = (id: string) => {
    setSelectedSubRegions(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const toggleCountry = (id: string) => {
    setSelectedCountries(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const toggleCategory = (id: string) => {
    setSelectedCategories(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('en-US').format(num);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 pt-16 flex items-center justify-center">
        <Navigation />
        <Spinner className="h-12 w-12 text-indigo-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 pt-16">
        <Navigation />
        <div className="container mx-auto px-4 py-8">
          <div className="bg-white rounded-lg shadow p-8 mt-6">
            <h1 className="text-2xl font-bold text-gray-800 mb-6">Media Sufficiency Dashboard</h1>
            <div className="text-red-500">{error}</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col bg-gray-50 min-h-screen">
      {/* Top Navigation */}
      <Navigation />
      
      {/* Dashboard Tabs - Using the same structure as Game Plan and Overview pages */}
      <div className="border-b border-gray-200 flex items-center justify-between px-4 py-2 mt-16">
        <div className="flex space-x-8">
          <Link href="/dashboard" className="px-1 py-4 text-sm font-medium text-gray-500 hover:text-indigo-500">
            Overview
          </Link>
          <Link href="/dashboard/game-plan" className="px-1 py-4 text-sm font-medium text-gray-500 hover:text-indigo-500">
            Game Plan
          </Link>
          <Link href="/dashboard/media-sufficiency" className="px-1 py-4 text-sm font-medium text-indigo-600 border-b-2 border-indigo-600">
            Sufficiency
          </Link>
          <Link href="/dashboard/media-similarity" className="px-1 py-4 text-sm font-medium text-gray-500 hover:text-indigo-500">
            Similarity
          </Link>
        </div>
        <div className="flex items-center">
          <select className="border border-gray-300 rounded-md px-3 py-1 text-sm bg-white">
            <option>FY 2025</option>
            <option>FY 2024</option>
            <option>FY 2023</option>
          </select>
        </div>
      </div>
      
      <div className="flex">
        {/* Left Sidebar Filters */}
        <div className={`${sidebarExpanded ? 'w-64' : 'w-16'} transition-all duration-300 ease-in-out bg-white border-r border-gray-200 p-4 flex flex-col h-[calc(100vh-8rem)]`}>
          <div className="flex items-center justify-between mb-6">
            <h2 className={`${sidebarExpanded ? 'block' : 'hidden'} text-lg font-semibold text-gray-800`}>Filters</h2>
            <button 
              onClick={() => setSidebarExpanded(!sidebarExpanded)}
              className="p-1 rounded-md text-gray-400 hover:text-gray-500 focus:outline-none"
            >
              {sidebarExpanded ? (
                <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 19l-7-7 7-7m8 14l-7-7 7-7" />
                </svg>
              ) : (
                <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 5l7 7-7 7M5 5l7 7-7 7" />
                </svg>
              )}
            </button>
          </div>
          
          <div className="overflow-y-auto">
            {/* Sub Region Filter */}
            <div className="mb-6">
              <h3 className={`${sidebarExpanded ? 'block' : 'hidden'} text-sm font-medium text-gray-500 mb-2`}>Sub Region</h3>
              <div className="space-y-1">
                {subRegionsList.map(region => (
                  <div key={region.id} className="flex items-center">
                    <input
                      id={`region-${region.id}`}
                      type="checkbox"
                      checked={selectedSubRegions.includes(region.id)}
                      onChange={() => toggleSubRegion(region.id)}
                      className="h-4 w-4 text-indigo-600 border-gray-300 rounded"
                    />
                    <label 
                      htmlFor={`region-${region.id}`} 
                      className={`${sidebarExpanded ? 'block' : 'hidden'} ml-2 text-sm text-gray-700`}
                    >
                      {region.name}
                    </label>
                  </div>
                ))}
            </div>
          </div>
          
          {/* Country Filter */}
          <div className="mb-6">
            <h3 className={`${sidebarExpanded ? 'block' : 'hidden'} text-sm font-medium text-gray-500 mb-2`}>Country</h3>
            <div className="space-y-1">
              {countriesList.map(country => (
                <div key={country.id} className="flex items-center">
                  <input
                    id={`country-${country.id}`}
                    type="checkbox"
                    checked={selectedCountries.includes(country.id)}
                    onChange={() => toggleCountry(country.id)}
                    className="h-4 w-4 text-indigo-600 border-gray-300 rounded"
                  />
                  <label 
                    htmlFor={`country-${country.id}`} 
                    className={`${sidebarExpanded ? 'block' : 'hidden'} ml-2 text-sm text-gray-700`}
                  >
                    {country.name}
                  </label>
                </div>
              ))}
            </div>
          </div>
          
          {/* Category Filter */}
          <div className="mb-6">
            <h3 className={`${sidebarExpanded ? 'block' : 'hidden'} text-sm font-medium text-gray-500 mb-2`}>Category</h3>
            <div className="space-y-1">
              {categoriesList.map(category => (
                <div key={category.id} className="flex items-center">
                  <input
                    id={`category-${category.id}`}
                    type="checkbox"
                    checked={selectedCategories.includes(category.id)}
                    onChange={() => toggleCategory(category.id)}
                    className="h-4 w-4 text-indigo-600 border-gray-300 rounded"
                  />
                  <label 
                    htmlFor={`category-${category.id}`} 
                    className={`${sidebarExpanded ? 'block' : 'hidden'} ml-2 text-sm text-gray-700`}
                  >
                    {category.name}
                  </label>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

        {/* Main Content */}
        <div className="flex-1 p-6 overflow-auto">
          <div className="mb-8">
            <h1 className="text-2xl font-bold text-gray-800 mb-4">Media Sufficiency Dashboard</h1>
            <p className="text-gray-600">Track and analyze media reach across campaigns</p>
          </div>

          {/* Combined Reach Section */}
          <div className="bg-white rounded-lg shadow mb-8">
            <div className="p-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-800">Combined Reach</h2>
              <p className="text-sm text-gray-500">Overall reach performance across all media types</p>
            </div>
            <div className="p-4 flex flex-wrap">
              <div className="w-full lg:w-2/3 pr-0 lg:pr-4 mb-4 lg:mb-0">
                <ResponsiveContainer width="100%" height={300}>
                  <ComposedChart data={combinedReachData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis unit="%" domain={[0, 120]} />
                    <Tooltip formatter={(value) => [`${value.toFixed(1)}%`, 'Reach']} />
                    <Legend />
                    <Bar dataKey="idealReach" name="Ideal Reach (100%)" fill={REACH_COLORS.ideal} />
                    <Line type="monotone" dataKey="currentReach" name="Current Reach (%)" stroke={REACH_COLORS.current} strokeWidth={2} />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
              <div className="w-full lg:w-1/3">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Campaign</th>
                        <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Target</th>
                        <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Reach %</th>
                        <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Check</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {combinedReachData.map((item, index) => (
                        <tr key={index}>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-900">{item.name}</td>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">{formatNumber(item.rawIdealReach)}</td>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">{item.reachPercentage.toFixed(1)}%</td>
                          <td className="px-3 py-2 whitespace-nowrap">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.status === 'nice' ? 'bg-green-100 text-green-800' : item.status === 'under' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'}`}>
                              {getStatusText(item.status)}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          {/* TV Reach Section */}
          <div className="bg-white rounded-lg shadow mb-8">
            <div className="p-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-800">TV Reach</h2>
              <p className="text-sm text-gray-500">Television media reach performance</p>
            </div>
            <div className="p-4 flex flex-wrap">
              <div className="w-full lg:w-2/3 pr-0 lg:pr-4 mb-4 lg:mb-0">
                <ResponsiveContainer width="100%" height={300}>
                  <ComposedChart data={tvReachData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis unit="%" domain={[0, 120]} />
                    <Tooltip formatter={(value) => [`${value.toFixed(1)}%`, 'Reach']} />
                    <Legend />
                    <Bar dataKey="idealReach" name="Ideal Reach (100%)" fill={REACH_COLORS.ideal} />
                    <Line type="monotone" dataKey="currentReach" name="Current Reach (%)" stroke={REACH_COLORS.current} strokeWidth={2} />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
              <div className="w-full lg:w-1/3">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Campaign</th>
                        <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Target</th>
                        <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Reach %</th>
                        <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Check</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {tvReachData.map((item, index) => (
                        <tr key={index}>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-900">{item.name}</td>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">{formatNumber(item.rawIdealReach)}</td>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">{item.reachPercentage.toFixed(1)}%</td>
                          <td className="px-3 py-2 whitespace-nowrap">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.status === 'nice' ? 'bg-green-100 text-green-800' : item.status === 'under' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'}`}>
                              {getStatusText(item.status)}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          {/* Digital Reach Section */}
          <div className="bg-white rounded-lg shadow mb-8">
            <div className="p-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-800">Digital Reach</h2>
              <p className="text-sm text-gray-500">Digital media reach performance</p>
            </div>
            <div className="p-4 flex flex-wrap">
              <div className="w-full lg:w-2/3 pr-0 lg:pr-4 mb-4 lg:mb-0">
                <ResponsiveContainer width="100%" height={300}>
                  <ComposedChart data={digitalReachData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis unit="%" domain={[0, 120]} />
                    <Tooltip formatter={(value) => [`${value.toFixed(1)}%`, 'Reach']} />
                    <Legend />
                    <Bar dataKey="idealReach" name="Ideal Reach (100%)" fill={REACH_COLORS.ideal} />
                    <Line type="monotone" dataKey="currentReach" name="Current Reach (%)" stroke={REACH_COLORS.current} strokeWidth={2} />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
              <div className="w-full lg:w-1/3">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Campaign</th>
                        <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Target</th>
                        <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Reach %</th>
                        <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Check</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {digitalReachData.map((item, index) => (
                        <tr key={index}>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-900">{item.name}</td>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">{formatNumber(item.rawIdealReach)}</td>
                          <td className="px-3 py-2 whitespace-nowrap text-sm text-gray-500">{item.reachPercentage.toFixed(1)}%</td>
                          <td className="px-3 py-2 whitespace-nowrap">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${item.status === 'nice' ? 'bg-green-100 text-green-800' : item.status === 'under' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'}`}>
                              {getStatusText(item.status)}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
