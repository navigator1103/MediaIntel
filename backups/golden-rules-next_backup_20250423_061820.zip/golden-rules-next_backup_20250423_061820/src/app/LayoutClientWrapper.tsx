'use client';

import LeftNavigation from '@/components/LeftNavigation';

export default function LayoutClientWrapper() {
  return <LeftNavigation />;
}
