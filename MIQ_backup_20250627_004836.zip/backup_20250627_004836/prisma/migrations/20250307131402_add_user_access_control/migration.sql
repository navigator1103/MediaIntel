-- AlterTable
ALTER TABLE "users" ADD COLUMN "accessible_brands" TEXT;
ALTER TABLE "users" ADD COLUMN "accessible_countries" TEXT;
ALTER TABLE "users" ADD COLUMN "accessible_pages" TEXT;
